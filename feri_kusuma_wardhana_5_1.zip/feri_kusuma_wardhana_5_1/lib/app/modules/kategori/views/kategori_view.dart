import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/kategori_controller.dart';

class KategoriView extends StatelessWidget {
  final String category;
  final KategoriController kategoriController = Get.put(KategoriController());

  KategoriView({required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Get.arguments),
      ),
      body: Obx(() {
        if (kategoriController.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        } else if (kategoriController.error.value.isNotEmpty) {
          return Center(child: Text(kategoriController.error.value));
        } else if (kategoriController.kategoriMakanan.isEmpty) {
          return const Center(child: Text("Meals Tidak Ditemukan"));
        } else {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var meal in kategoriController.kategoriMakanan)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      elevation: 4,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                            child: Image.network(
                              meal['strMealThumb'],
                              fit: BoxFit.cover,
                              height: 200,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              meal['strMeal'],
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          );
        }
      }),
    );
  }
}
