import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class KategoriController extends GetxController {
  final kategoriMakanan = [].obs;
  final isLoading = true.obs;
  final error = ''.obs;

  @override
  void onInit() {
    super.onInit();
    ambilKategoriMakanan(Get.arguments);
  }

  void ambilKategoriMakanan(String category) async {
    try {
      isLoading.value = true;
      final response = await http.get(Uri.parse(
          'https://www.themealdb.com/api/json/v1/1/filter.php?c=$category'));
      if (response.statusCode == 200) {
        final List<dynamic> ambilMakanan = json.decode(response.body)['meals'];
        if (ambilMakanan.isNotEmpty) {
          kategoriMakanan.value = ambilMakanan;
        } else {
          kategoriMakanan.value = [];
        }
      } else {
        throw Exception('gagal untuk load makanan berdasarkan kategori');
      }
    } catch (e) {
      error.value = 'Error makanan: $e';
    } finally {
      isLoading.value = false;
    }
  }
}
