import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomeController extends GetxController {
  final categories = [].obs;
  final kategoriFilter = [].obs;

  @override
  void onInit() {
    ambilKategori();
    super.onInit();
  }

  void ambilKategori() async {
    try {
      final response = await http.get(
          Uri.parse('https://www.themealdb.com/api/json/v1/1/categories.php'));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List<dynamic> kategoriAmbil = data['categories'];

        if (kategoriAmbil.isNotEmpty) {
          categories.value = kategoriAmbil;
          kategoriFilter.value = kategoriAmbil;
        } else {
          throw Exception('list meal tidak ditemukan');
        }
      } else {
        throw Exception('gagal untuk load home');
      }
    } catch (e) {
      print('Error home: $e');
    }
  }

  void search(String query) {
    if (query.isEmpty) {
      kategoriFilter.value = categories;
    } else {
      kategoriFilter.value = categories
          .where((category) => category['strCategory']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
    }
  }
}
